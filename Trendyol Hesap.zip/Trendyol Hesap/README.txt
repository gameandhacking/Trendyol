# Trendyol-Araçları
Python ile yazılmış Trendyol araçları

# Bu tam olarak ne?
Basitçe, hesap açmanızı ve kuponları sorgulamanızı sağlayan bir program

# Kurulum [Termux]
- Öncelikle dosyamızı downloads klasörüne atalım (.zip ten cikarttiktan sonra)
- Sonra Termuxa girin yada konsola dosyanın olduğu yere gidin 

(Termux için:
- cd storage
- cd Trendyol Hesap

Windows için:
- cd Desktop
- cd Trendyol Hesap)

Daha sonra bu komutları yazın

Termux için:

- pkg install python
- python main.py

Windows için:

- python main.py

Sonra kullanmaya başlayabilirsiniz..

Açılan hesaplar ve toplanan kuponlar dosya konumunda openedmail.txt ve toplanan_kupon.txt olarak gözükecektir.

# Nasıl çalışır?

- [Pythonu] indirin
- Konsola``python main.py`` yazın. Bu kadar :)

# Olası hatalar
### requests modülü yok 
cmd ekranına (konsola) ``pip install requests``, ``pip3 install requests`` veya ``python -m pip install requests`` yazabilirsiniz.


# Sorunum var
Sorununuz, sorunuz var ise https://masterixsohbet bölümünden yazabilirsiniz.


YAPACAĞINIZ KÖTÜ İŞLEMLERDEN HİÇBİR ŞEKİLDE SORUMLU DEĞİLİM!
